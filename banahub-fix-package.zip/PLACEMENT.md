# BANAHub — Fix Package Placement

Your last upload put the fix files as .zip archives at the repo ROOT
(`files (10).zip`, `files (13).zip`) — GitHub never extracts zips, and
even unzipped, they'd sit in the wrong folder. None of these fixes are
live yet. This package fixes that.

## 1. Delete from the repo root
- `files (10).zip`
- `files (13).zip`
- `fix_and_deploy.py` (targets a different/stale repo name — confusing, not needed)

## 2. Replace the entire `Banahub platform/` folder
Copy everything inside this package's `Banahub platform/` folder into
your repo's `Banahub platform/` folder, overwriting existing files.
This includes: admin.html, config.js, api.js, index.html, platform.html,
events.html, programs.html, payment-success.html, brand-glass.css —
every file touched across this whole conversation, cumulative.

## 3. Run the SQL (not part of Git — run directly in Supabase)
`supabase_and_sql/security_hardening.sql` in the Supabase SQL editor.

## 4. Deploy the Edge Functions (also not part of Git)
```
supabase functions deploy create-checkout-session
supabase functions deploy stripe-webhook --no-verify-jwt
supabase functions deploy luma-sync-event
supabase functions deploy luma-sync-guests
supabase functions deploy notify-admin-login-attempt
```
Then set secrets: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
`LUMA_API_KEY`, `RESEND_API_KEY`, `ADMIN_ALERT_EMAIL`.

## 5. Commit and push
```
git add -A
git commit -m "Fix admin panels, add events/programs/payments/Luma, security hardening"
git push
```
Vercel redeploys automatically on push.
