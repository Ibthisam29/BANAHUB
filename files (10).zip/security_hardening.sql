-- BANAHub — Security hardening
-- Run in Supabase SQL Editor (project: ositmmczozefrdzcgxrp)

-- ══════════════════════════════════════════════════════════════════
-- PAYMENTS — transactions table (idempotent; same table used across
-- programs, events, and FundMatch contact unlocks)
-- ══════════════════════════════════════════════════════════════════
create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  email text,                          -- for guest checkouts pre-auth
  type text not null,                  -- 'program_payment','event_registration','contact_unlock','subscription'
  item_type text,                      -- 'program' | 'event'
  item_id uuid,
  amount numeric not null,
  currency text default 'SGD',
  stripe_session_id text unique,
  stripe_payment_intent_id text,
  status text default 'pending',       -- pending, completed, failed, refunded
  created_at timestamptz default now()
);
alter table transactions enable row level security;

create policy "transactions_owner_read" on transactions
  for select using (auth.uid() = user_id);

create policy "transactions_admin_read" on transactions
  for select using (
    exists (select 1 from auth.users u where u.id = auth.uid() and u.raw_app_meta_data->>'role' = 'admin')
  );

-- Guest checkout confirmation: status lookup by exact session_id only.
-- Deliberately NOT an RLS policy (a "using (true)" policy would expose
-- the whole table via anon SELECT) — instead a narrow function that
-- returns just the status string for one row.
create or replace function get_transaction_status(p_session_id text)
returns text
language plpgsql
security definer
as $$
declare
  v_status text;
begin
  select status into v_status from transactions where stripe_session_id = p_session_id;
  return coalesce(v_status, 'error');
end;
$$;
grant execute on function get_transaction_status(text) to anon, authenticated;

-- No client insert/update policy on purpose — only the stripe-webhook
-- Edge Function (using the service_role key, which bypasses RLS) may
-- write transactions. This is the actual security boundary: a client
-- can never mark its own payment as "completed".

-- ══════════════════════════════════════════════════════════════════
-- PROGRAMS TABLE (was missing — admin panel was fully stubbed)
-- ══════════════════════════════════════════════════════════════════
create table if not exists programs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  type text default 'Cohort',
  status text default 'draft',        -- draft, upcoming, active, closed
  start_date date,
  end_date date,
  region text,
  description text,
  max_participants int,
  price_amount numeric default 0,     -- 0 = free
  currency text default 'SGD',
  published boolean default false,
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);
alter table programs enable row level security;

-- events also needs a price for paid registrations (Capital & Growth
-- Exchange showcase slots, private dinner, etc). Add if missing:
alter table events add column if not exists price_amount numeric default 0;
alter table events add column if not exists currency text default 'SGD';

create policy "programs_public_read" on programs
  for select using (published = true);

create policy "programs_admin_all" on programs
  for all using (
    exists (select 1 from auth.users u where u.id = auth.uid() and u.raw_app_meta_data->>'role' = 'admin')
  );

-- Same policy pattern should exist on `events` — confirm it does; if not:
-- create policy "events_public_read" on events for select using (published = true);
-- create policy "events_admin_all" on events for all using (
--   exists (select 1 from auth.users u where u.id = auth.uid() and u.raw_app_meta_data->>'role' = 'admin')
-- );

-- ══════════════════════════════════════════════════════════════════
-- LOGIN ATTEMPT LOGGING + RATE LIMITING
-- ══════════════════════════════════════════════════════════════════
create table if not exists login_attempts (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  success boolean not null,
  ip_address text,
  user_agent text,
  created_at timestamptz default now()
);
alter table login_attempts enable row level security;

-- Anyone (including anon, pre-auth) can INSERT an attempt record — this is
-- how failed logins get logged before a session exists. No SELECT for anon.
create policy "login_attempts_insert_anyone" on login_attempts
  for insert with check (true);

create policy "login_attempts_admin_read" on login_attempts
  for select using (
    exists (select 1 from auth.users u where u.id = auth.uid() and u.raw_app_meta_data->>'role' = 'admin')
  );

-- Rate-limit check: call BEFORE attempting sign-in from the client.
-- Blocks after 5 failed attempts for the same email within 15 minutes.
create or replace function check_login_rate_limit(p_email text)
returns boolean
language plpgsql
security definer
as $$
declare
  fail_count int;
begin
  select count(*) into fail_count
  from login_attempts
  where email = p_email
    and success = false
    and created_at > now() - interval '15 minutes';
  return fail_count < 5;
end;
$$;

-- Allow anon to call the rate-limit check (read-only, no data exposure)
grant execute on function check_login_rate_limit(text) to anon, authenticated;

-- ══════════════════════════════════════════════════════════════════
-- ADMIN LOGIN ALERT — trigger fires on every INSERT into login_attempts
-- targeting the admin route, calls an Edge Function via pg_net which
-- emails the owner. Requires the "notify-admin-login-attempt" Edge
-- Function to be deployed (see edge-function-notify-admin.ts) and the
-- pg_net extension enabled (Database → Extensions → pg_net).
-- ══════════════════════════════════════════════════════════════════
create extension if not exists pg_net;

create or replace function notify_admin_on_login_attempt()
returns trigger
language plpgsql
security definer
as $$
declare
  is_admin_email boolean;
begin
  -- Server-side check: is this email actually an admin account?
  -- (never trust a client-supplied "is this the admin route" flag)
  select exists(
    select 1 from users u
    where u.email = new.email and u.role = 'admin'
  ) into is_admin_email;

  if is_admin_email then
    perform net.http_post(
      url := 'https://ositmmczozefrdzcgxrp.supabase.co/functions/v1/notify-admin-login-attempt',
      headers := jsonb_build_object('Content-Type', 'application/json'),
      body := jsonb_build_object(
        'email', new.email,
        'success', new.success,
        'ip_address', new.ip_address,
        'user_agent', new.user_agent,
        'created_at', new.created_at
      )
    );
  end if;
  return new;
end;
$$;

create trigger trg_notify_admin_login
  after insert on login_attempts
  for each row execute function notify_admin_on_login_attempt();
